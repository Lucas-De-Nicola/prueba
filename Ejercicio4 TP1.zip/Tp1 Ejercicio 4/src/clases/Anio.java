package clases;

public class Anio {
	
	private String[] meses;
	private Integer[] diasXMes;
	
	public Anio() {
		this.meses = new String[]{"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
		this.diasXMes = new Integer[] {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	}

	public String[] getMeses() {
		return meses;
	}

	public Integer[] getDiasXMes() {
		return diasXMes;
	}

	public String getNombreDelMes(int numeroMes) {
		int i = numeroMes - 1;
		
		return this.meses[i];
	}
	
	public int diasTranscurridos(int numeroMes) {
		int i = numeroMes - 1;
		int dias = 0;
		
		for (int j = 0; j < i; j++) {
			dias += this.diasXMes[j];
		}
		return dias;
	}
}
