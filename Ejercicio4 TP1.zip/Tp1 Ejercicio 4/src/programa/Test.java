package programa;

import clases.Anio;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Anio anio = new Anio();
		
		System.out.println("Siendo lunes 23 de Marzo han transcurrido " + (anio.diasTranscurridos(3)+23) + " dias en lo que va del anio.");
		
		
	}

}
